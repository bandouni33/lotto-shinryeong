# SOURCE_EXCERPT_BACK.md

> 저작권 등록 제출용 — 전체 .py 소스 연결본 **뒷부분** (약 1,650줄)
> 생성일: 2026-07-17

```python
                if(currentMode === 'delete') {{
                    if(selectedDelete.has(num)) selectedDelete.delete(num);
                    else {{
                        selectedDelete.add(num);
                        selectedFixed.delete(num);
                        luckyNumbers.delete(num);
                    }}
                }} else if(currentMode === 'fixed') {{
                    if(selectedFixed.has(num)) selectedFixed.delete(num);
                    else {{
                        if(selectedFixed.size >= 5) return;
                        selectedFixed.add(num);
                        selectedDelete.delete(num);
                        luckyNumbers.delete(num);
                    }}
                }} else if(currentMode === 'lucky') {{
                    if(luckyNumbers.has(num)) luckyNumbers.delete(num);
                    else {{
                        luckyNumbers.add(num);
                        selectedDelete.delete(num);
                        selectedFixed.delete(num);
                    }}
                }}
                initGrid();
            }}

            function generateCombination() {{
                const count = parseInt(document.getElementById('gameCount').value);
                const available = [];
                for(let i=1; i<=45; i++) {{
                    if(!selectedDelete.has(i)) available.push(i);
                }}

                currentResults = [];
                const resultArea = document.getElementById('resultArea');
                resultArea.innerHTML = '';

                for(let g=0; g<count; g++) {{
                    let game = Array.from(selectedFixed);
                    let pool = available.filter(n => !selectedFixed.has(n));
                    
                    // 행운수 우선 적용 로직
                    let luckyPool = pool.filter(n => luckyNumbers.has(n));
                    let normalPool = pool.filter(n => !luckyNumbers.has(n));
                    
                    // 행운수 섞기
                    luckyPool.sort(() => Math.random() - 0.5);
                    normalPool.sort(() => Math.random() - 0.5);
                    
                    let combinedPool = [...luckyPool, ...normalPool];
                    
                    while(game.length < 6 && combinedPool.length > 0) {{
                        game.push(combinedPool.shift());
                    }}
                    
                    game.sort((a,b) => a-b);
                    currentResults.push(game);
                    renderGame(game);
                }}
            }}

            function getBallColor(n) {{
                if(n <= 10) return '#fbc400';
                if(n <= 20) return '#69c8f2';
                if(n <= 30) return '#ff7272';
                if(n <= 40) return '#aaa';
                return '#b0d840';
            }}

            function renderGame(nums) {{
                const row = document.createElement('div');
                row.className = 'result-row';
                nums.forEach(n => {{
                    const ball = document.createElement('div');
                    ball.className = 'ball';
                    ball.style.backgroundColor = getBallColor(n);
                    ball.innerText = n;
                    row.appendChild(ball);
                }});
                document.getElementById('resultArea').appendChild(row);
            }}

            function saveResults() {{
                if(currentResults.length === 0) return;
                window.parent.postMessage({{
                    type: 'save_lotto',
                    results: currentResults
                }}, '*');
                alert('결과가 저장되었습니다!');
            }}

            window.addEventListener('message', function(e) {{
                if(e.data.type === 'nav') {{
                    // Streamlit reruns on query param change
                }}
            }});

            initGrid();
        </script>
    </body>
    </html>
    """

    components.html(thunder_ui_html, height=900, scrolling=True)

    # ─── 시스템 관리자 메뉴 (필요 시) ───
    with st.expander("🛠️ 시스템 관리자 메뉴"):
        if st.button("세션 초기화"):
            st.session_state.clear()
            st.rerun()

# 호출 확인
if __name__ == "__main__":
    render()

# ===== FILE: premium_test.py (77 lines) =====
import streamlit as st
import streamlit.components.v1 as components
import pandas as pd

# ==========================================
# 0. 페이지 기본 설정
# ==========================================
st.set_page_config(page_title="고급필터 테스트", layout="wide")

st.markdown("<h2 style='color:#FFB300; font-weight:800;'>👑 전문가용 고급필터 (프리미엄)</h2>", unsafe_allow_html=True)
st.markdown("나만의 패턴을 직접 수정하고 저장하여 언제든 불러올 수 있습니다.")
st.markdown("---")

# ==========================================
# 1. 상단: 툴팁(?)이 적용된 기본필터 세팅 영역
# ==========================================
st.markdown("#### 1. 기본필터 직관적 세팅")

# 레이아웃을 3단 분할하여 공간 활용
col1, col2, col3 = st.columns(3)

with col1:
    # help="" 안에 설명을 넣으면 라벨 옆에 '?' 아이콘이 자동 생성됩니다.
    st.selectbox("홀짝 비율", ["선택", "6:0", "5:1", "4:2", "3:3", "2:4", "1:5", "0:6"], 
                 help="홀수와 짝수의 출현 비율입니다. (예: 3:3은 홀수 3개, 짝수 3개)")
    st.selectbox("저고 비율", ["선택", "6:0", "5:1", "4:2", "3:3", "2:4", "1:5", "0:6"], 
                 help="저(1~22)와 고(23~45)의 출현 비율입니다.")

with col2:
    st.slider("당첨번호 총합 구간", min_value=15, max_value=255, value=(70, 205), 
              help="당첨번호 6개를 모두 더한 값의 최소/최대 구간을 마우스로 드래그하여 설정합니다.")

with col3:
    st.multiselect("볼 색상 수 (체크박스 대체)", ["1색", "2색", "3색", "4색", "5색(모두)"], 
                   help="출현할 로또 공의 색상 종류 개수를 지정합니다. (예: 3색은 3가지 색상만 나옴)")

# ==========================================
# 2. 중단: 나만의 필터 (데이터 에디터)
# ==========================================
st.markdown("<br><br>", unsafe_allow_html=True)
st.markdown("#### 2. 나만의 패턴 직접 수정 (엑셀 연동 대기중)")
st.info("💡 엑셀을 업로드하거나, 아래 표의 빈칸을 더블클릭하여 숫자를 직접 수정할 수 있습니다.")

# 전문가들이 다룰 초기 더미 데이터 세팅
df_premium = pd.DataFrame({
    "그룹명": ["소수", "3배수", "쌍둥이수", "이월수"],
    "고정수": ["", "", "", ""],
    "번호입력(앞,뒤 콤마 필수)": [
        ",2,3,5,7,11,13,17,19,23,29,31,37,41,43,", 
        ",3,6,9,12,15,18,21,24,27,30,33,36,39,42,45,", 
        ",11,22,33,44,", 
        "" # 이월수는 회차마다 다르므로 비워둠
    ],
    "최소": [0, 0, 0, 0],
    "최대": [4, 4, 1, 2]
})

# num_rows="dynamic" 옵션으로 행 추가/삭제까지 가능하게 함
edited_df = st.data_editor(df_premium, num_rows="dynamic", use_container_width=True, hide_index=True)

# ==========================================
# 3. 하단: 조합 제어 및 로컬 저장/불러오기 영역
# ==========================================
st.markdown("---")
st.markdown("#### 3. 세팅 보존 및 조합 실행")

col_save, col_load, col_target, col_start = st.columns([1.5, 1.5, 1, 1.5])

with col_save:
    st.button("💾 이 화면 세팅을 내 PC에 파일로 저장")
with col_load:
    st.button("📂 내 PC에서 저장된 세팅 불러오기")
with col_target:
    st.number_input("희망 추출 수량", min_value=1, max_value=10000, value=100, step=10, 
                    help="엔진이 조건에 맞는 조합 중 몇 개를 최종적으로 뽑아낼지 결정합니다.")
with col_start:
    st.button("🚀 나만의 고급 조합 엔진 가동", type="primary")

# ===== FILE: src/__init__.py (0 lines) =====

# ===== FILE: src/data/__init__.py (0 lines) =====

# ===== FILE: src/data/mock_draws.py (15 lines) =====
import random


def generate_mock_draws(count: int = 100, seed: int = 42) -> list[list[int]]:
    """동행복권 스타일 가상 역대 당첨 번호 생성"""
    rng = random.Random(seed)
    draws = []
    for _ in range(count):
        draw = sorted(rng.sample(range(1, 46), 6))
        draws.append(draw)
    return draws


def get_last_draw(draws: list[list[int]]) -> list[int]:
    return draws[-1] if draws else []

# ===== FILE: src/engine/__init__.py (0 lines) =====

# ===== FILE: src/engine/generator.py (9 lines) =====
import random

from src.models.combination import LottoCombination


def generate_random_combination(seed: int | None = None) -> LottoCombination:
    rng = random.Random(seed)
    nums = tuple(sorted(rng.sample(range(1, 46), 6)))
    return LottoCombination(numbers=nums)

# ===== FILE: src/engine/pipeline.py (17 lines) =====
from src.filters.base import LottoFilter
from src.models.combination import LottoCombination


class FilterPipeline:
    def __init__(self, filters: list[LottoFilter]):
        self.filters = filters

    def apply(self, combo: LottoCombination, context: dict) -> bool:
        return all(f.passes(combo, context) for f in self.filters)

    def filter_combinations(
        self,
        combinations: list[LottoCombination],
        context: dict,
    ) -> list[LottoCombination]:
        return [c for c in combinations if self.apply(c, context)]

# ===== FILE: src/filters/__init__.py (0 lines) =====

# ===== FILE: src/filters/base.py (12 lines) =====
from abc import ABC, abstractmethod

from src.models.combination import LottoCombination


class LottoFilter(ABC):
    name: str
    tier_required: str  # "free" | "premium"

    @abstractmethod
    def passes(self, combo: LottoCombination, context: dict) -> bool:
        pass

# ===== FILE: src/filters/consecutive.py (24 lines) =====
from src.filters.base import LottoFilter
from src.models.combination import LottoCombination


class ConsecutiveExcludeFilter(LottoFilter):
    """3개 이상 연속 번호가 있으면 제외"""

    name = "연속 번호 제외"
    tier_required = "premium"

    def __init__(self, max_consecutive: int = 2):
        self.max_consecutive = max_consecutive

    def passes(self, combo: LottoCombination, context: dict) -> bool:
        nums = combo.sorted_numbers
        streak = 1
        for i in range(1, len(nums)):
            if nums[i] == nums[i - 1] + 1:
                streak += 1
                if streak > self.max_consecutive:
                    return False
            else:
                streak = 1
        return True

# ===== FILE: src/filters/high_low_carry.py (38 lines) =====
from src.filters.base import LottoFilter
from src.models.combination import LottoCombination

ALLOWED_HIGH_LOW_RATIOS = {
    (2, 4),
    (3, 3),
    (4, 2),
    (1, 5),
    (5, 1),
}


class HighLowRatioFilter(LottoFilter):
    """1~22 저 / 23~45 고"""

    name = "고저 비율 제한"
    tier_required = "premium"

    def passes(self, combo: LottoCombination, context: dict) -> bool:
        return (combo.low_count, combo.high_count) in ALLOWED_HIGH_LOW_RATIOS


class CarryOverFilter(LottoFilter):
    """직전 회차 당첨 번호와 겹치는 개수 제한"""

    name = "이월수 필터"
    tier_required = "premium"

    def __init__(self, min_overlap: int = 0, max_overlap: int = 2):
        self.min_overlap = min_overlap
        self.max_overlap = max_overlap

    def passes(self, combo: LottoCombination, context: dict) -> bool:
        last_draw = context.get("last_draw")
        if not last_draw:
            return True
        overlap = len(set(combo.numbers) & set(last_draw))
        return self.min_overlap <= overlap <= self.max_overlap

# ===== FILE: src/filters/odd_even.py (19 lines) =====
from src.filters.base import LottoFilter
from src.models.combination import LottoCombination

ALLOWED_ODD_EVEN_RATIOS = {
    (3, 3),
    (2, 4),
    (4, 2),
    (1, 5),
    (5, 1),
}


class OddEvenRatioFilter(LottoFilter):
    name = "홀짝 비율 제한"
    tier_required = "free"

    def passes(self, combo: LottoCombination, context: dict) -> bool:
        ratio = (combo.odd_count, combo.even_count)
        return ratio in ALLOWED_ODD_EVEN_RATIOS

# ===== FILE: src/filters/sum_range.py (14 lines) =====
from src.filters.base import LottoFilter
from src.models.combination import LottoCombination


class SumRangeFilter(LottoFilter):
    name = "총합 범위 제한"
    tier_required = "free"

    def __init__(self, min_sum: int = 100, max_sum: int = 170):
        self.min_sum = min_sum
        self.max_sum = max_sum

    def passes(self, combo: LottoCombination, context: dict) -> bool:
        return self.min_sum <= combo.total_sum <= self.max_sum

# ===== FILE: src/models/__init__.py (0 lines) =====

# ===== FILE: src/models/combination.py (41 lines) =====
from dataclasses import dataclass


@dataclass(frozen=True)
class LottoCombination:
    numbers: tuple[int, ...]

    def __post_init__(self):
        if len(self.numbers) != 6:
            raise ValueError("로또 조합은 6개 번호여야 합니다")
        if len(set(self.numbers)) != 6:
            raise ValueError("중복 번호가 있습니다")
        if any(n < 1 or n > 45 for n in self.numbers):
            raise ValueError("번호는 1~45 사이여야 합니다")

    @property
    def sorted_numbers(self) -> list[int]:
        return sorted(self.numbers)

    @property
    def total_sum(self) -> int:
        return sum(self.numbers)

    @property
    def odd_count(self) -> int:
        return sum(1 for n in self.numbers if n % 2 == 1)

    @property
    def even_count(self) -> int:
        return 6 - self.odd_count

    @property
    def low_count(self) -> int:
        return sum(1 for n in self.numbers if n <= 22)

    @property
    def high_count(self) -> int:
        return 6 - self.low_count

    def __str__(self) -> str:
        return " ".join(f"{n:02d}" for n in self.sorted_numbers)

# ===== FILE: src/models/membership.py (10 lines) =====
from enum import Enum


class MembershipTier(str, Enum):
    FREE = "free"
    PREMIUM = "premium"

    @property
    def display_name(self) -> str:
        return {"free": "기본(무료)", "premium": "프리미엄(유료)"}[self.value]

# ===== FILE: src/services/__init__.py (0 lines) =====

# ===== FILE: src/services/combination_service.py (55 lines) =====
import random
from dataclasses import dataclass

from src.data.mock_draws import generate_mock_draws, get_last_draw
from src.engine.generator import generate_random_combination
from src.models.combination import LottoCombination
from src.models.membership import MembershipTier
from src.services.subscription import get_filter_names_for_tier, get_pipeline_for_tier


@dataclass
class CombinationResult:
    combinations: list[LottoCombination]
    last_draw: list[int]
    tier: MembershipTier
    filters_applied: list[str]
    requested_count: int

    @property
    def is_complete(self) -> bool:
        return len(self.combinations) >= self.requested_count


def generate_combinations(
    tier: MembershipTier,
    count: int = 5,
    max_attempts: int = 50_000,
    draw_seed: int = 42,
) -> CombinationResult:
    draws = generate_mock_draws(count=100, seed=draw_seed)
    last_draw = get_last_draw(draws)
    context = {"last_draw": last_draw, "draw_history": draws}

    pipeline = get_pipeline_for_tier(tier)
    results: list[LottoCombination] = []
    seen: set[tuple[int, ...]] = set()

    rng = random.Random()
    attempts = 0
    while len(results) < count and attempts < max_attempts:
        attempts += 1
        combo = generate_random_combination(seed=rng.randint(0, 10**9))
        if combo.numbers in seen:
            continue
        if pipeline.apply(combo, context):
            seen.add(combo.numbers)
            results.append(combo)

    return CombinationResult(
        combinations=results,
        last_draw=last_draw,
        tier=tier,
        filters_applied=get_filter_names_for_tier(tier),
        requested_count=count,
    )

# ===== FILE: src/services/subscription.py (30 lines) =====
from src.engine.pipeline import FilterPipeline
from src.filters.base import LottoFilter
from src.filters.consecutive import ConsecutiveExcludeFilter
from src.filters.high_low_carry import CarryOverFilter, HighLowRatioFilter
from src.filters.odd_even import OddEvenRatioFilter
from src.filters.sum_range import SumRangeFilter
from src.models.membership import MembershipTier

FREE_FILTERS: list[LottoFilter] = [
    OddEvenRatioFilter(),
    SumRangeFilter(min_sum=100, max_sum=170),
]

PREMIUM_FILTERS: list[LottoFilter] = FREE_FILTERS + [
    ConsecutiveExcludeFilter(max_consecutive=2),
    HighLowRatioFilter(),
    CarryOverFilter(min_overlap=0, max_overlap=2),
]


def get_filters_for_tier(tier: MembershipTier) -> list[LottoFilter]:
    return FREE_FILTERS if tier == MembershipTier.FREE else PREMIUM_FILTERS


def get_pipeline_for_tier(tier: MembershipTier) -> FilterPipeline:
    return FilterPipeline(get_filters_for_tier(tier))


def get_filter_names_for_tier(tier: MembershipTier) -> list[str]:
    return [f.name for f in get_filters_for_tier(tier)]

# ===== FILE: tests/test_four_filters.py (107 lines) =====
"""4종 필터 엔진 검증 테스트."""

import itertools
import pickle
import unittest

from lotto_engine import (
    combo_gaps,
    passes_absolute_filters,
    passes_interval_filters,
    passes_set_filters,
    prep_absolute_filters,
    prep_interval_filters,
    prep_set_filters,
    run_filtering_engine,
)


class FourFilterLogicTests(unittest.TestCase):
    def test_combo_gaps(self):
        self.assertEqual(combo_gaps((1, 2, 3, 4, 5, 6)), [1, 1, 1, 1, 1])
        self.assertEqual(combo_gaps((1, 3, 10, 20, 30, 45)), [2, 7, 10, 10, 15])

    def test_set_filter_matches_step2(self):
        combo = (1, 11, 21, 31, 41, 45)
        rules = [{"targets": {1, 11, 21, 31, 41}, "min": 1, "max": 5}]
        self.assertTrue(passes_set_filters(set(combo), rules))

    def test_interval_uses_gaps_not_ball_numbers(self):
        combo = (1, 2, 3, 4, 5, 6)
        gap_rules = [{"targets": {1}, "min": 5, "max": 5}]
        ball_rules = [{"targets": {2, 3, 4, 5, 6}, "min": 6, "max": 6}]
        self.assertTrue(passes_interval_filters(combo, gap_rules))
        self.assertFalse(passes_set_filters(set(combo), ball_rules))

    def test_absolute_only_applies_when_number_in_combo(self):
        combo_set = {1, 2, 3, 4, 5, 6}
        grouped = {
            1: [{"targets": {1, 11, 21}, "min": 1, "max": 1}],
            8: [{"targets": {8, 18, 28}, "min": 1, "max": 1}],
        }
        self.assertTrue(passes_absolute_filters(combo_set, grouped))

    def test_absolute_skips_rules_for_absent_numbers(self):
        combo_set = {1, 2, 3, 4, 5, 6}
        grouped = {40: [{"targets": {40}, "min": 1, "max": 1}]}
        self.assertTrue(passes_absolute_filters(combo_set, grouped))


class SavedFiltersIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open("saved_filters.pkl", "rb") as f:
            cls.saved = pickle.load(f)

    def test_each_sheet_has_rules(self):
        for key in ("basic", "special", "interval", "absolute"):
            df = self.saved[key]
            self.assertGreater(len(df), 0, f"{key} sheet should not be empty")

    def test_all_four_sheets_produce_results(self):
        total = len(run_filtering_engine(self.saved, apply_premium_patterns=False))
        self.assertGreater(total, 0, "4종 필터 통합 결과는 0개가 아니어야 함")
        print(f"\n[검증] 4종 필터 통합 통과 조합: {total:,}개")

    def test_admin_mode_skips_premium_checkbox_filters(self):
        total = len(run_filtering_engine(self.saved, apply_premium_patterns=False))
        with_premium_empty = len(run_filtering_engine(self.saved, apply_premium_patterns=True))
        self.assertGreater(total, 0)
        self.assertEqual(with_premium_empty, 0)

    def test_interval_logic_changes_outcome(self):
        interval_df = self.saved["interval"]
        gap_rules = prep_interval_filters(interval_df)
        set_rules = prep_set_filters(interval_df)

        gap_pass = 0
        set_pass = 0
        for combo in itertools.combinations(range(1, 46), 6):
            combo_set = set(combo)
            if passes_interval_filters(combo, gap_rules):
                gap_pass += 1
            if passes_set_filters(combo_set, set_rules):
                set_pass += 1

        self.assertNotEqual(gap_pass, set_pass)

    def test_absolute_scoped_beats_global_and(self):
        absolute_df = self.saved["absolute"]
        scoped_rules = prep_absolute_filters(absolute_df)
        global_rules = prep_set_filters(absolute_df)

        scoped_pass = 0
        global_pass = 0
        for combo in itertools.combinations(range(1, 46), 6):
            combo_set = set(combo)
            if passes_absolute_filters(combo_set, scoped_rules):
                scoped_pass += 1
            if passes_set_filters(combo_set, global_rules):
                global_pass += 1

        self.assertGreater(scoped_pass, 0)
        self.assertEqual(global_pass, 0)


if __name__ == "__main__":
    unittest.main()

# ===== FILE: tests/test_marketing_db.py (60 lines) =====
"""marketing_db 단위 테스트."""

import os
import tempfile
import unittest

import marketing_db as mdb


class MarketingDbTests(unittest.TestCase):
    def setUp(self):
        self._tmpdir = tempfile.TemporaryDirectory()
        self._orig_path = mdb.DB_PATH
        mdb.DB_PATH = os.path.join(self._tmpdir.name, "test_lotto.db")
        mdb.init_marketing_tables()

    def tearDown(self):
        mdb.DB_PATH = self._orig_path
        self._tmpdir.cleanup()

    def test_tables_are_independent(self):
        sms_id = mdb.enqueue_sms("01012345678", "정기구독")
        combo_count = mdb.bulk_insert_lotto_combinations(
            1200,
            [(1, 2, 3, 4, 5, 6), (7, 8, 9, 10, 11, 12)],
        )
        self.assertGreater(sms_id, 0)
        self.assertEqual(combo_count, 2)
        self.assertEqual(mdb.get_combination_count_by_draw(1200), 2)

    def test_sms_queue_no_lotto_numbers(self):
        mdb.enqueue_sms("01099998888", "일반구매")
        conn = mdb._connect()
        cols = {
            row[1]
            for row in conn.execute("PRAGMA table_info(sms_queue)").fetchall()
        }
        conn.close()
        self.assertNotIn("num1", cols)
        self.assertNotIn("draw_round", cols)

    def test_bulk_insert_and_win_rank_group_by(self):
        mdb.bulk_insert_lotto_combinations(1201, [(1, 2, 3, 4, 5, 6)])
        conn = mdb._connect()
        conn.execute(
            "UPDATE lotto_combinations SET win_rank = 1 WHERE draw_round = 1201"
        )
        conn.commit()
        conn.close()
        summary = mdb.get_win_rank_counts_by_draw(1201)
        self.assertEqual(summary.get(1), 1)

    def test_parse_text_rows(self):
        text = "1,2,3,4,5,6\n7 8 9 10 11 12\nbad row\n"
        rows = mdb.parse_combination_rows_from_text(text)
        self.assertEqual(len(rows), 2)


if __name__ == "__main__":
    unittest.main()

# ===== FILE: user_page.py (964 lines) =====

import streamlit as st
import streamlit.components.v1 as components
import base64
import os
import pandas as pd

# 🚨 [여기에 추가!] 관리자 모드가 켜지면 대시보드 파일로 즉시 강제 점프!
if st.session_state.get("go_to_admin", False):
    st.session_state.go_to_admin = False # 깃발 내리기
    st.switch_page("admin_dashboard.py")  # 👈 이 한 줄이 핵심 치트키입니다.

# 2. ✅ 관리자 모드일 때만 나타나는 사이드바 메뉴
if st.session_state.get("is_admin", False):
    with st.sidebar:
        st.markdown("## ⚙️ 관리자 제어 센터")
        if st.button("📊 대시보드로 바로가기", key="admin_sidebar_dash_6n36s5"):
            st.switch_page("admin_dashboard.py")

# ==========================================
# 1. 페이지 초기 설정 및 상태 관리
# ==========================================
st.set_page_config(page_title="로\u200b또신령", page_icon="K-325.jpg", layout="centered", initial_sidebar_state="collapsed")

current_page = st.query_params.get("page", "main")

# ===============================================================================
# ⚠️⚠️⚠️ [관리자 필수 확인] 매주 이 숫자 6개를 직접 수정하세요 ⚠️⚠️⚠️
# 앞 번호일수록 유력한 순서로 입력 (예: 44가 가장 유력, 7이 가장 약함)
# ⚠️⚠️⚠️ 다른 코드는 건드리지 말고 이 줄의 숫자만 바꾸세요 ⚠️⚠️⚠️
lucky_display = [44, 10, 23, 5, 40, 7]
# ===============================================================================

def get_image_base64(file_path):
    if os.path.exists(file_path):
        with open(file_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    return ""

icon_base64 = get_image_base64("K-325.jpg")


# ==========================================
# 📺 화면 1: 메인 페이지 (Main View) - 🎨 모바일 앱 고급 UI 적용 완료
# ==========================================
if current_page == "main":
    st.markdown("""
    <style>
        .stApp { background-color: #12182b; color: white; }
        .block-container { padding-top: 5px !important; padding-bottom: 0px !important; padding-left: 12px !important; padding-right: 12px !important; max-width: 600px; }
        section[data-testid="stSidebar"] { display: none; }
        header[data-testid="stHeader"] { display: none; }

        div[data-columns="true"] {
            display: flex !important;
            flex-direction: row !important;
            flex-wrap: nowrap !important;
            align-items: center !important;
            gap: 6px !important;
            width: 100% !important;
        }
        div[data-testid="stColumn"] { padding: 0px !important; margin: 0px !important; }

        div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) {
            display: flex !important;
            flex-direction: row !important;
            flex-wrap: nowrap !important;
            align-items: center !important;
            justify-content: space-between !important;
            gap: 6px !important;
            width: 100% !important;
            background: linear-gradient(145deg, #1c2645, #12182b) !important;
            border-radius: 14px !important;
            padding: 6px 10px !important;
            border: 1px solid #2a3a60 !important;
            box-shadow: 0 4px 8px rgba(0,0,0,0.4) !important;
            min-height: 44px !important;
            box-sizing: border-box !important;
        }
        div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) > div[data-testid="stColumn"]:nth-child(1) {
            flex: 1 1 0 !important;
            min-width: 0 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: flex-start !important;
        }
        div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) > div[data-testid="stColumn"]:nth-child(2) {
            flex: 1 1 0 !important;
            min-width: 0 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
        }
        div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) > div[data-testid="stColumn"]:nth-child(3) {
            flex: 1 1 0 !important;
            min-width: 0 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: flex-end !important;
        }

        div[data-testid="stPopover"] {
            width: auto !important;
            min-width: 120px !important;
        }
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button,
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button[data-testid="stBaseButton-secondary"],
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button[data-testid="baseButton-secondary"],
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button[kind="secondary"],
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stButton"] > button {
            background: linear-gradient(145deg, #1e88e5, #1565c0) !important;
            background-color: #1976d2 !important;
            background-image: linear-gradient(145deg, #1e88e5, #1565c0) !important;
            color: #ffffff !important;
            border: 1px solid #0d47a1 !important;
            border-color: #0d47a1 !important;
            border-radius: 10px !important;
            font-size: 11px !important;
            font-weight: 800 !important;
            line-height: 1.2 !important;
            letter-spacing: -0.1px !important;
            padding: 9px 14px !important;
            width: auto !important;
            min-width: 120px !important;
            height: 40px !important;
            min-height: 40px !important;
            box-shadow: 0 3px 6px rgba(0,0,0,0.35) !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            overflow: visible !important;
            white-space: nowrap !important;
            flex-shrink: 0 !important;
            -webkit-font-smoothing: antialiased !important;
            text-rendering: optimizeLegibility !important;
        }
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button *,
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button p,
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button span,
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button div,
        .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stButton"] > button * {
            color: #ffffff !important;
            -webkit-text-fill-color: #ffffff !important;
            background: transparent !important;
            background-color: transparent !important;
        }
        /* 팝업: body 포털 기준 ( .stApp 바깥 렌더링 대응 ) */
        html body div[data-baseweb="popover"],
        body > div[data-baseweb="popover"] {
            z-index: 9999 !important;
            position: fixed !important;
            isolation: isolate !important;
        }
        html body [data-testid="stPopoverBody"],
        body [data-testid="stPopoverBody"] {
            background-color: #1a2542 !important;
            background: #1a2542 !important;
            color: #ffffff !important;
            border: 1px solid #f9a825 !important;
            border-radius: 12px !important;
            min-width: 240px !important;
            padding: 14px 16px !important;
            box-sizing: border-box !important;
            opacity: 1 !important;
            visibility: visible !important;
            z-index: 9999 !important;
            position: fixed !important;
            isolation: isolate !important;
            pointer-events: auto !important;
        }
        html body [data-testid="stPopoverBody"] *,
        html body [data-testid="stPopoverBody"] p,
        html body [data-testid="stPopoverBody"] h1,
        html body [data-testid="stPopoverBody"] h2,
        html body [data-testid="stPopoverBody"] h3,
        html body [data-testid="stPopoverBody"] div[data-testid="stMarkdownContainer"],
        html body [data-testid="stPopoverBody"] div[data-testid="element-container"],
        html body [data-testid="stPopoverBody"] div[data-testid="stMarkdownContainer"] * {
            color: #ffffff !important;
            -webkit-text-fill-color: #ffffff !important;
            background-color: transparent !important;
            background: transparent !important;
            line-height: 1.6 !important;
            white-space: normal !important;
            word-break: keep-all !important;
            font-size: 14px !important;
            font-weight: 600 !important;
            -webkit-font-smoothing: antialiased !important;
            opacity: 1 !important;
            visibility: visible !important;
        }
        html body [data-testid="stPopoverBody"] h3 {
            font-size: 16px !important;
            font-weight: 800 !important;
            margin-bottom: 8px !important;
        }
    </style>
    """, unsafe_allow_html=True)

    # 엑셀에서 데이터 가져오기
    try:
        df = pd.read_excel("로또최근당첨내역.xlsb", engine='pyxlsb', header=None)
        row = df.iloc[4].tolist() 
        draw_no = str(row[1]).replace(".0", "") + "회" 
        numbers = sorted([int(x) for x in row[3:9]])
        import re
        bonus_val = int(re.sub(r'[^0-9]', '', str(row[9])))
    except Exception as e:
        draw_no = "오류"
        numbers = [3, 8, 9, 22, 28, 42]
        bonus_val = 45

    # 상단 로고 + 회전 볼 오버레이

    def get_ball_color(n):
        if 1 <= n <= 10: return "#f9a825"
        if 11 <= n <= 20: return "#1976d2"
        if 21 <= n <= 30: return "#e53935"
        if 31 <= n <= 40: return "#757575"
        return "#388e3c"

    balls_css = ""
    for i, num in enumerate(lucky_display):
        angle = i * 30
        color = get_ball_color(num)
        balls_css += f"""
        .orbit-ball-{i} {{
            position: absolute; width: 30px; height: 30px; border-radius: 50%;
            background: radial-gradient(circle at 35% 35%, {color}, #000);
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 900; font-size: 15px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.8);
            box-shadow: 2px 3px 5px rgba(0,0,0,0.6), inset 2px 2px 4px rgba(255,255,255,0.4);
            top: 50%; left: 50%;
            margin-top: -11px; margin-left: -11px;
            animation: orbit{i} 6s linear infinite;
        }}
        @keyframes orbit{i} {{
            from {{ transform: rotate({angle}deg) translateX(82px) rotate(-{angle}deg); }}
            to {{ transform: rotate({angle + 360}deg) translateX(82px) rotate(-{angle + 360}deg); }}
        }}
        """


    st.markdown(f"""
    <style>
        @keyframes orbitSpin {{
            0% {{ transform: rotate({0}deg) translateY(-52px) rotate(-{0}deg); opacity: 0.7; }}
            50% {{ opacity: 1; transform: rotate(180deg) translateY(-52px) rotate(-180deg); }}
            100% {{ transform: rotate(360deg) translateY(-52px) rotate(-360deg); opacity: 0.7; }}
        }}
        @keyframes glowPulse {{
            0%, 100% {{ box-shadow: 0 0 15px rgba(255,179,0,0.8), 0 0 30px rgba(255,179,0,0.4); }}
            50% {{ box-shadow: 0 0 25px rgba(255,179,0,1), 0 0 50px rgba(255,179,0,0.6); }}
        }}
        .logo-wrapper {{
            position: relative; width: 175px; height: 175px; margin: 0 auto;
        }}
        .hero-with-brand {{
            position: relative;
            text-align: center;
            min-height: 198px;
            padding: 16px 0 20px 0;
            margin-top: -5px;
            overflow: visible;
            box-sizing: border-box;
        }}
        .app-name-vertical {{
            position: absolute;
            left: 4px;
            top: 16px;
            width: 52px;
            height: 175px;
            margin: 0;
            padding: 0;
            z-index: 3;
            pointer-events: none;
            font-size: 22px;
            font-weight: 800;
            line-height: 1.08;
            letter-spacing: 0.1em;
            color: #ffffff;
            overflow: visible;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 3px;
        }}
        .app-name-vertical span {{
            position: static;
            margin: 0;
            display: block;
            opacity: 0;
            transform-origin: left center;
            will-change: transform, opacity, filter;
            background: linear-gradient(180deg, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0.92) 42%, rgba(200,225,255,0.85) 58%, rgba(255,255,255,0.4) 100%);
            background-size: 100% 220%;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: spiritMirageSuck 14s cubic-bezier(0.42, 0, 0.58, 1) infinite,
                       spiritCharShimmer 3.6s ease-in-out infinite;
        }}
        .app-name-vertical span:nth-child(1) {{ --y-start: -11px; animation-delay: 0s, 0s; }}
        .app-name-vertical span:nth-child(2) {{ --y-start: -4px; animation-delay: 0.35s, 0.12s; }}
        .app-name-vertical span:nth-child(3) {{ --y-start: 4px; animation-delay: 0.7s, 0.24s; }}
        .app-name-vertical span:nth-child(4) {{ --y-start: 11px; animation-delay: 1.05s, 0.36s; }}
        @keyframes spiritMirageSuck {{
            0% {{
                opacity: 0;
                transform: translate(0px, var(--y-start, 0px)) scale(1);
                filter: blur(1.4px);
                background-position: 0% 25%;
            }}
            5% {{
                opacity: 0.78;
                transform: translate(2px, calc(var(--y-start, 0px) * 0.85)) scale(0.98);
                filter: blur(0.25px);
            }}
            11% {{
                opacity: 0.22;
                transform: translate(5px, calc(var(--y-start, 0px) * 0.7)) scale(0.96);
                filter: blur(1.1px);
            }}
            18% {{
                opacity: 0.86;
                transform: translate(9px, calc(var(--y-start, 0px) * 0.55)) scale(0.93);
                filter: blur(0);
                background-position: 0% 78%;
            }}
            25% {{
                opacity: 0.3;
                transform: translate(13px, calc(var(--y-start, 0px) * 0.42)) scale(0.89);
                filter: blur(0.9px);
            }}
            33% {{
                opacity: 0.82;
                transform: translate(18px, calc(var(--y-start, 0px) * 0.32)) scale(0.84);
                filter: blur(0.2px);
            }}
            41% {{
                opacity: 0.26;
                transform: translate(23px, calc(var(--y-start, 0px) * 0.22)) scale(0.78);
                filter: blur(1.3px);
            }}
            49% {{
                opacity: 0.74;
                transform: translate(28px, calc(var(--y-start, 0px) * 0.14)) scale(0.72);
                filter: blur(0.45px);
                background-position: 0% 35%;
            }}
            57% {{
                opacity: 0.2;
                transform: translate(32px, calc(var(--y-start, 0px) * 0.08)) scale(0.66);
                filter: blur(1.6px);
            }}
            65% {{
                opacity: 0.68;
                transform: translate(36px, calc(var(--y-start, 0px) * 0.04)) scale(0.58);
                filter: blur(0.7px);
            }}
            73% {{
                opacity: 0.16;
                transform: translate(39px, calc(var(--y-start, 0px) * 0.02)) scale(0.5);
                filter: blur(2px);
            }}
            81% {{
                opacity: 0.52;
                transform: translate(42px, 0px) scale(0.42);
                filter: blur(1.4px);
                background-position: 0% 70%;
            }}
            89% {{
                opacity: 0.1;
                transform: translate(45px, 0px) scale(0.34);
                filter: blur(2.8px);
            }}
            96% {{
                opacity: 0.38;
                transform: translate(47px, 0px) scale(0.28);
                filter: blur(3.2px);
            }}
            100% {{
                opacity: 0;
                transform: translate(48px, 0px) scale(0.22);
                filter: blur(4px);
                background-position: 0% 25%;
            }}
        }}
        @keyframes spiritCharShimmer {{
            0%, 100% {{ background-position: 0% 22%; }}
            50% {{ background-position: 0% 82%; }}
        }}
        .logo-img {{
            width: 105px; height: 105px; border-radius: 50%; border: 3px solid #ffb300;
            position: absolute; top: calc(50% - 1px); left: calc(50% - 1px); transform: translate(-50%, -50%);
            object-fit: cover; animation: glowPulse 2s infinite;
        }}
        {balls_css}
    </style>
    <div class="hero-with-brand">
        <p class="app-name-vertical" aria-label="로또신령">
            <span>로</span><span>또</span><span>신</span><span>령</span>
        </p>
        <div class="logo-wrapper">
            <img class="logo-img" src="data:image/jpeg;base64,{icon_base64}">
            <div class="orbit-ball-0">{lucky_display[0]}</div>
            <div class="orbit-ball-1">{lucky_display[1]}</div>
            <div class="orbit-ball-2">{lucky_display[2]}</div>
            <div class="orbit-ball-3">{lucky_display[3]}</div>
            <div class="orbit-ball-4">{lucky_display[4]}</div>
            <div class="orbit-ball-5">{lucky_display[5]}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)


    # 🟢 1. 로또볼 디자인 (3D 입체감 & 크기 확대)
    col1 = st.columns([1])[0]
    with col1:
        def get_ball_style(n):
            if 1 <= n <= 10: return "background: radial-gradient(circle at 35% 35%, #ffeb3b, #f9a825, #f57f17);"
            if 11 <= n <= 20: return "background: radial-gradient(circle at 35% 35%, #4fc3f7, #1976d2, #0d47a1);"
            if 21 <= n <= 30: return "background: radial-gradient(circle at 35% 35%, #ef5350, #e53935, #b71c1c);"
            if 31 <= n <= 40: return "background: radial-gradient(circle at 35% 35%, #bdbdbd, #757575, #424242);"
            return "background: radial-gradient(circle at 35% 35%, #81c784, #388e3c, #1b5e20);"

        balls_html = "".join([f'<div style="{get_ball_style(n)} width:34px; height:34px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-weight:900; font-size:15px; margin-right:4px; box-shadow: 2px 3px 5px rgba(0,0,0,0.5), inset -3px -3px 5px rgba(0,0,0,0.4), inset 2px 2px 4px rgba(255,255,255,0.6); text-shadow: 1px 1px 2px rgba(0,0,0,0.8);">{n}</div>' for n in numbers])
        
        st.markdown(f"""
        <div style="background: linear-gradient(145deg, #1c2645, #12182b); border-radius:16px; padding:12px 10px; border: 1px solid #2a3a60; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 6px 12px rgba(0,0,0,0.5); margin-bottom: 12px;">
            <div style="color:#ffb300; font-size:13px; font-weight:900; line-height:1; margin-right:8px; letter-spacing:-0.5px; white-space:nowrap;">최근당첨번호 <span style="color:#fff;">{draw_no}</span></div>
            <div style="display:flex; align-items:center;">
                {balls_html}
                <span style="color:#aaa; font-weight:900; font-size:18px; margin: 0 4px;">+</span>
                <div style="{get_ball_style(bonus_val)} width:34px; height:34px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-weight:900; font-size:15px; box-shadow: 2px 3px 5px rgba(0,0,0,0.5), inset -3px -3px 5px rgba(0,0,0,0.4), inset 2px 2px 4px rgba(255,255,255,0.6); text-shadow: 1px 1px 2px rgba(0,0,0,0.8);">{bonus_val}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # 역대 최고 당첨금 (한 줄 정렬 - 3구역 space-between)
    col_title, col_amount, col_btn = st.columns(3)
    with col_title:
        st.markdown("""
        <div style="display:flex; align-items:center; gap:4px; white-space:nowrap; width:100%;">
            <span style="color:#b0bec5; font-size:11px; font-weight:bold; letter-spacing:-0.3px; line-height:1;">🏆 역대 최고 당첨 금액 순위</span>
        </div>
        """, unsafe_allow_html=True)
    with col_amount:
        st.markdown("""
        <div style="display:flex; align-items:center; gap:6px; white-space:nowrap; justify-content:center; width:100%;">
            <div style="background: radial-gradient(circle at 35% 35%, #ef5350, #e53935, #b71c1c); width:18px; height:18px; border-radius:50%; text-align:center; line-height:18px; color:white; font-weight:bold; font-size:11px; box-shadow: 1px 2px 3px rgba(0,0,0,0.5); flex-shrink:0;">1</div>
            <span style="color:#fff; font-weight:900; font-size:16px; letter-spacing:-0.5px; line-height:1;">407억 원</span>
        </div>
        """, unsafe_allow_html=True)
    with col_btn:
        with st.popover("더 보러가기", key="main_rank_more_6n36s5"):
            st.markdown("### 🏆 역대 당\u200b\u200b첨금 TOP 5")
            st.write("1위: 407억 (1회)")
            st.write("2위: 369억 (51회)")
            st.write("3위: 346억 (100회)")

    components.html("""
    <script>
    (function() {
        const doc = window.parent.document;
        if (!doc.getElementById('rank-more-btn-style')) {
            const style = doc.createElement('style');
            style.id = 'rank-more-btn-style';
            style.textContent = `
                html body .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button,
                html body .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button[data-testid="stBaseButton-secondary"],
                html body .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button[data-testid="baseButton-secondary"],
                html body .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button[kind="secondary"],
                html body .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stButton"] > button {
                    background: linear-gradient(145deg, #1e88e5, #1565c0) !important;
                    background-color: #1976d2 !important;
                    background-image: linear-gradient(145deg, #1e88e5, #1565c0) !important;
                    color: #ffffff !important;
                    border: 1px solid #0d47a1 !important;
                    border-color: #0d47a1 !important;
                }
                html body .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button *,
                html body .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stPopover"] button p,
                html body .stApp div[data-testid="stHorizontalBlock"]:has([data-testid="stPopover"]) div[data-testid="stButton"] > button * {
                    color: #ffffff !important;
                    -webkit-text-fill-color: #ffffff !important;
                    background: transparent !important;
                }
            `;
            doc.head.appendChild(style);
        }
        if (!doc.getElementById('rank-popover-layer-fix')) {
            const popStyle = doc.createElement('style');
            popStyle.id = 'rank-popover-layer-fix';
            popStyle.textContent = `
                html body div[data-baseweb="popover"],
                body > div[data-baseweb="popover"] {
                    z-index: 9999 !important;
                    position: fixed !important;
                    isolation: isolate !important;
                }
                html body [data-testid="stPopoverBody"],
                body [data-testid="stPopoverBody"] {
                    background-color: #1a2542 !important;
                    background: #1a2542 !important;
                    color: #ffffff !important;
                    border: 1px solid #f9a825 !important;
                    border-radius: 12px !important;
                    min-width: 240px !important;
                    padding: 14px 16px !important;
                    box-sizing: border-box !important;
                    opacity: 1 !important;
                    visibility: visible !important;
                    z-index: 9999 !important;
                    position: fixed !important;
                    isolation: isolate !important;
                    pointer-events: auto !important;
                }
                html body [data-testid="stPopoverBody"] *,
                html body [data-testid="stPopoverBody"] p,
                html body [data-testid="stPopoverBody"] h3,
                html body [data-testid="stPopoverBody"] div[data-testid="stMarkdownContainer"],
                html body [data-testid="stPopoverBody"] div[data-testid="element-container"],
                html body [data-testid="stPopoverBody"] div[data-testid="stMarkdownContainer"] * {
                    color: #ffffff !important;
                    -webkit-text-fill-color: #ffffff !important;
                    background-color: transparent !important;
                    background: transparent !important;
                    opacity: 1 !important;
                    visibility: visible !important;
                }
            `;
            doc.head.appendChild(popStyle);
        }
    })();
    </script>
    """, height=0)

    components.html("""
    <script>
    (function() {
        function safeVibrate() {
            if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
                try { navigator.vibrate(70); } catch (e) {}
            }
        }
        const doc = window.parent.document;
        doc.querySelectorAll('div[data-testid="stPopover"] button').forEach(function(btn) {
            if (btn.dataset.mainVibrateBound) return;
            const label = (btn.innerText || '').trim();
            if (label.indexOf('더 보러가기') !== -1 || label.indexOf('더보러가기') !== -1 || label === '➡️') {
                btn.dataset.mainVibrateBound = '1';
                btn.addEventListener('click', safeVibrate, { passive: true });
            }
        });
    })();
    </script>
    """, height=0)

    # 🟢 2. 하단 4버튼 메뉴 (모바일 앱 스타일, 강한 햅틱 진동 추가)
    st.markdown("""
    <style>
    .menu-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 7px; }
    
    .menu-box { 
        background: linear-gradient(145deg, #1c2645, #101628); 
        border-radius: 20px; 
        padding: 18px 10px; 
        text-align: center; 
        box-shadow: 6px 8px 16px rgba(0,0,0,0.6), inset 1px 1px 2px rgba(255,255,255,0.1); 
        cursor: pointer; 
        transition: all 0.1s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
    }
    
    /* ⚡ 터치 시 강하게 눌리는 입체 효과 */
    .menu-box:active { 
        transform: scale(0.93) translateY(4px); 
        box-shadow: 2px 3px 6px rgba(0,0,0,0.6), inset 4px 6px 12px rgba(0,0,0,0.8), inset -2px -2px 6px rgba(255,255,255,0.05); 
    }
    
    /* 3D 느낌의 크고 선명한 이모티콘 */
    .menu-icon { font-size: 36px; margin-bottom: 8px; line-height: 1; filter: drop-shadow(2px 4px 6px rgba(0,0,0,0.5)); }
    .menu-title { color: #ffffff; font-weight: 900; font-size: 16px; margin-bottom: 2px; letter-spacing: 0.5px; }
    .menu-sub { color: #9aa5b1; font-size: 13px; font-weight: 600; }
    
    /* 테두리 글로우 효과 */
    .gold { border: 2px solid rgba(255, 179, 0, 0.7); }
    .blue { border: 2px solid rgba(41, 182, 246, 0.7); }
    .green { border: 2px solid rgba(102, 187, 106, 0.7); }
    .purple { border: 2px solid rgba(171, 71, 188, 0.7); }
    </style>

<div class="menu-grid">
    <a href="?page=thunder&fresh=1" target="_self" style="text-decoration:none; display:block;">
        <div class="menu-box gold">
            <div class="menu-icon">⚡</div>
            <div class="menu-title">번\u200b\u200b개조합</div>
            <div class="menu-sub">빠른 조합</div>
        </div>
    </a>
    <a href="?page=advanced" target="_self" style="text-decoration:none; display:block;">
        <div class="menu-box blue">
            <div class="menu-icon">👑</div>
            <div class="menu-title">고급필터</div>
            <div class="menu-sub">전문가 분석용</div>
        </div>
    </a>
    <a href="?page=auto" target="_self" style="text-decoration:none; display:block;">
        <div class="menu-box purple">
            <div class="menu-icon">💎</div>
            <div class="menu-title">자\u200b동\u200b조합</div>
            <div class="menu-sub">준비중입니다</div>
        </div>
    </a>
    <a href="?page=stats" target="_self" style="text-decoration:none; display:block;">
        <div class="menu-box green">
            <div class="menu-icon">📊</div>
            <div class="menu-title">통계센터</div>
            <div class="menu-sub">데이터분석</div>
        </div>
    </a>
</div>
    """, unsafe_allow_html=True)

    components.html("""
    <script>
    (function() {
        function safeVibrate() {
            if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
                try { navigator.vibrate(70); } catch (e) {}
            }
        }
        const doc = window.parent.document;

        doc.querySelectorAll('.menu-grid a').forEach(function(el) {
            if (el.dataset.mainVibrateBound) return;
            el.dataset.mainVibrateBound = '1';
            el.addEventListener('click', safeVibrate, { passive: true });
        });
    })();
    </script>
    """, height=0)


# ==========================================
# ⚡ 화면 2: 번개조합 (Thunder View) - 로직 분리됨
# ==========================================
elif current_page == "thunder":
    import page_thunder
    page_thunder.render(admin_lucky=lucky_display)

elif current_page == "birthday":
    import page_birthday
    page_birthday.render()

# ==========================================
# 💎 화면: 자동조합 상세 (Auto Combination View)
# ==========================================
elif current_page == "auto":
    import page_auto
    page_auto.render()

# ==========================================
# 🤖 화면 3: 고급필터 상세 페이지 (Advanced Filter View)
# ==========================================
elif current_page == "advanced":
    if os.path.exists("admin_filter.py"):
        with open("admin_filter.py", "r", encoding="utf-8") as f:
            exec(f.read())
    else:
        st.error("admin_filter.py 파일을 찾을 수 없습니다. 파일이 같은 폴더에 있는지 확인해주세요.")

# ==========================================
# 📊 화면 4: 통계 대시보드 (Stats View)
# ==========================================
# ==========================================
# 📊 [안전하게 추가] 통계 대시보드 (Stats View)
# ==========================================
elif current_page == "stats":
    st.markdown("""
    <style>
        .stApp { background-color: #12182b; color: white; }
        .block-container { padding: 10px !important; max-width: 600px; }
        section[data-testid="stSidebar"], header[data-testid="stHeader"] { display: none; }
        
        /* 탭(Tab) 디자인 고급화 */
        button[data-baseweb="tab"] { background-color: transparent !important; color: #888 !important; font-weight: bold; font-size: 15px; padding-bottom: 12px !important; }
        button[data-baseweb="tab"][aria-selected="true"] { color: #ffb300 !important; border-bottom: 3px solid #ffb300 !important; }
        
        /* 통계 카드 디자인 */
        .stat-card { background: linear-gradient(145deg, #1c2645, #12182b); border-radius: 14px; padding: 16px; border: 1px solid #2a3a60; margin-bottom: 14px; box-shadow: 0 4px 8px rgba(0,0,0,0.4); }
        .stat-title { color: #4fc3f7; font-size: 14px; font-weight: 900; margin-bottom: 8px; border-bottom: 1px solid #2a3a60; padding-bottom: 6px; display: flex; justify-content: space-between; align-items: center; }
        .stat-value { color: #ffffff; font-size: 16px; font-weight: bold; line-height: 1.4; }
        .highlight { color: #ffeb3b; font-size: 22px; font-weight: 900; }
        .tag { background: #2a3a60; padding: 2px 8px; border-radius: 12px; font-size: 11px; color: #aaa; }
    </style>
    """, unsafe_allow_html=True)

    # 1. 상단 네비게이션
    col_back, col_title = st.columns([3, 7])
    with col_back:
        if st.button("⬅️ 메인으로", use_container_width=True):
            st.query_params.clear()
            st.rerun()
    with col_title:
        st.markdown("<h3 style='color:#ffb300; margin:0; padding-top:2px;'>📊 로또 통계 센터</h3>", unsafe_allow_html=True)

    st.markdown("<div style='margin-top:15px;'></div>", unsafe_allow_html=True)

    # 2. 엑셀 데이터 기반 통계 집계
    try:
        from lotto_stats import compute_all_stats

        stats = compute_all_stats("로또최근당첨내역.xlsb")
        draw_no = stats["latest"]["draw_no"]
        numbers = stats["latest"]["numbers"]
        sum_val = stats["latest"]["sum"]
        ac_val = stats["latest"]["ac"]
        hot_items = stats["hot"]
        hot_display = " · ".join(str(n) for n, _ in hot_items)
        cold_nums = stats["cold"]
        cold_display = ", ".join(str(n) for n in cold_nums) if cold_nums else "없음"
        carry_count = stats["carry"]["count"]
        carry_checked = stats["carry"]["checked"]
        is_sum_good = "🔥 이상적" if 120 <= sum_val <= 150 else "❄️ 주의"
        from lotto_stats import get_marketing_win_rank_summary

        try:
            draw_round_int = int(str(draw_no).replace("회", "").strip())
            st.session_state["marketing_win_rank_summary"] = get_marketing_win_rank_summary(
                draw_round_int
            )
        except (TypeError, ValueError):
            st.session_state["marketing_win_rank_summary"] = {}
    except Exception as e:
        stats = None
        draw_no, numbers, sum_val, ac_val = "오류", [0, 0, 0, 0, 0, 0], 0, "-"
        hot_display, cold_display = "-", "-"
        carry_count, carry_checked = 0, 0
        is_sum_good = "-"
        st.session_state["marketing_win_rank_summary"] = {}
        st.error(f"통계 데이터 로딩 오류: {e}")

    # 3. 3개의 탭으로 모바일 화면 최적화
    tab1, tab2, tab3 = st.tabs(["🧠 전문가 지표", "🔥 출현 빈도", "🎯 패턴 분석"])

    # --- TAB 1: 전문가 지표 ---
    with tab1:
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-title"><span>1. AC값 (산술적 복잡도)</span> <span class="tag">최근 {draw_no}회차</span></div>
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <span class="stat-value" style="color:#aaa; font-size:13px;">이상적 구간 (7~10)</span>
                <span class="highlight">{ac_val}</span>
            </div>
            <div style="font-size:12px; color:#4fc3f7; margin-top:8px;">💡 AC값이 7 이상일 때 1등 당첨 확률이 통계적으로 가장 높습니다.</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-title"><span>2. 당첨 번호 총합 (Sum)</span> <span class="tag">최근 {draw_no}회차</span></div>
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <span class="stat-value">총합: {sum_val}</span>
                <span class="highlight" style="font-size:16px;">{is_sum_good} (120~150 강세)</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-title">3. 이월수 출현 패턴</div>
            <div class="stat-value">최근 {carry_checked}회 중 <span style="color:#ffb300;">{carry_count}회</span> 이월수 출현</div>
            <div style="font-size:12px; color:#aaa; margin-top:4px;">직전 회차 당첨번호가 다음 회차에도 포함된 실제 집계입니다.</div>
        </div>
        """, unsafe_allow_html=True)

    # --- TAB 2: 출현 빈도 ---
    with tab2:
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-title">4. 역대 최다 출현 (Hot 10)</div>
            <div class="stat-value" style="letter-spacing: 1px;">
                {hot_display}
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-title">5. 장기 미출현 (Cold)</div>
            <div class="stat-value">
                <span style="color:#4fc3f7;">{cold_display}</span>
            </div>
            <div style="font-size:12px; color:#aaa; margin-top:4px;">최근 15회차 동안 1~6구에 미출현한 번호입니다.</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-title">6. 색상별 당첨 비율 (최근 10회)</div>
            <div style="display:flex; height:24px; border-radius:12px; overflow:hidden; margin-top:10px;">
                <div style="background:#f9a825; width:20%;" title="노랑 (1~10)"></div>
                <div style="background:#1976d2; width:35%;" title="파랑 (11~20)"></div>
                <div style="background:#e53935; width:25%;" title="빨강 (21~30)"></div>
                <div style="background:#757575; width:10%;" title="회색 (31~40)"></div>
                <div style="background:#388e3c; width:10%;" title="초록 (41~45)"></div>
            </div>
            <div style="font-size:12px; color:#aaa; margin-top:8px; text-align:center;">현재 <span style="color:#4fc3f7; font-weight:bold;">파란공(11~20)</span>이 가장 강세입니다.</div>
        </div>
        """, unsafe_allow_html=True)

    # --- TAB 3: 패턴 분석 (lotto_stats.py 실데이터) ---
    with tab3:
        if stats is not None:
            pattern = stats["pattern"]
            pat_n = pattern["basis_n"]
            oe = pattern["odd_even"]
            lh = pattern["low_high"]
            dec = pattern["decade"]
            ld = pattern["last_digit"]

            odd_even_text = (
                f'현재 누적 트렌드 ➡️ <span style="color:#ffb300;">'
                f'홀 {oe["top_odds"]} : 짝 {oe["top_evens"]}</span> '
                f'(최근 {oe["checked"]}회 중 {oe["top_count"]}회)'
            )
            low_high_text = (
                f'현재 누적 트렌드 ➡️ <span style="color:#ffb300;">'
                f'저 {lh["top_low"]} : 고 {lh["top_high"]}</span> '
                f'(최근 {lh["checked"]}회 중 {lh["top_count"]}회)'
            )

            if dec["warnings"]:
                decade_lines = []
                for w in dec["warnings"]:
                    decade_lines.append(
                        f'⚠️ <span style="color:#e53935;">{w["band"]} 구간({w["range"]})</span> '
                        f'{w["streak"]}주 연속 전멸 현상 발생'
                    )
                decade_text = "<br/>".join(decade_lines)
            else:
                totals = dec["band_totals"]
                summary_parts = [
                    f'{name} {totals[name]}회'
                    for name, _, _ in (
                        ("1번대", 1, 9),
                        ("10번대", 10, 19),
                        ("20번대", 20, 29),
                        ("30번대", 30, 39),
                        ("40번대", 40, 45),
                    )
                ]
                decade_text = (
                    f'최근 {dec["checked"]}회 각 구간 출현: '
                    f'<span style="color:#4fc3f7;">{" · ".join(summary_parts)}</span>'
                )

            last_digit_text = (
                f'최근 동끝수 <span style="color:#4fc3f7;">[ {ld["top_digit"]} ]</span> '
                f'({ld["top_count"]}회 출현, 최근 {ld["checked"]}회 기준)'
            )
        else:
            pat_n = 0
            odd_even_text = low_high_text = decade_text = last_digit_text = "데이터 로딩 오류"

        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-title">7. 홀짝 비율 <span class="tag">최근 {pat_n}회</span></div>
            <div class="stat-value">
                {odd_even_text}
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-title">8. 고저 비율 (1~22 vs 23~45) <span class="tag">최근 {pat_n}회</span></div>
            <div class="stat-value">
                {low_high_text}
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-title">9. 번호대별 분포 현상 <span class="tag">최근 {pat_n}회</span></div>
            <div class="stat-value">
                {decade_text}
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-title">10. 끝수 (일의 자리) 출현 <span class="tag">최근 {pat_n}회</span></div>
            <div class="stat-value">
                {last_digit_text}
            </div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown(
        '<p style="font-size:11px; color:#888; text-align:center; margin-top:20px; line-height:1.5;">'
        "※ 본 통계는 과거 데이터 집계이며, 로또는 완전 무작위 추첨으로 "
        "다음 회차 결과를 보장하지 않습니다"
        "</p>",
        unsafe_allow_html=True,
    )


# ==========================================================
# 👑 메인 화면 맨 아래 관리자 메뉴
# ==========================================================
if current_page == "main":
    st.markdown("---")
    st.markdown("""
    <div class="main-admin-menu-marker" aria-hidden="true"></div>
    <style>
    .main-admin-menu-marker { display: none !important; }

    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] {
        background-color: #000000 !important;
        border: 1px solid #2a2a2a !important;
        border-radius: 10px !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] details {
        background-color: #000000 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] summary {
        background-color: #000000 !important;
        color: #ffffff !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] summary:hover {
        background-color: #111111 !important;
        color: #ffffff !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] summary p,
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] summary span,
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] summary div,
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] summary svg {
        color: #ffffff !important;
        fill: #ffffff !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] [data-testid="stExpanderDetails"] {
        background-color: #000000 !important;
        border-top: 1px solid #333333 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] [data-testid="stExpanderDetails"] > div {
        background-color: #000000 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] button[kind="secondary"],
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] button[data-testid="stBaseButton-secondary"],
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] button {
        background-color: #3a3a3a !important;
        color: #ffffff !important;
        border: 1px solid #555555 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] button:hover {
        background-color: #4a4a4a !important;
        color: #ffffff !important;
        border-color: #666666 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] button p,
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] button span,
    div[data-testid="stVerticalBlock"]:has(.main-admin-menu-marker) div[data-testid="stExpander"] button div {
        color: #ffffff !important;
    }
    </style>
    """, unsafe_allow_html=True)
    with st.expander("🛠️ 시스템 관리자 메뉴"):
        if st.button("📊 대시보드로 이동", key="admin_btn_dashboard"):
            st.session_state.is_admin = True
            st.session_state.go_to_admin = True
            st.rerun()
```