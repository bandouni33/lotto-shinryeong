# CODE_STATS.md

## Python 소스 파일 통계

| 파일 경로 | 줄 수 |
|-----------|------:|
| admin_dashboard.py | 351 |
| admin_filter.py | 1,597 |
| app.py | 18 |
| birthday_db.py | 73 |
| data_analyzer.py | 46 |
| frontend/__init__.py | 0 |
| frontend/app_runner.py | 36 |
| frontend/components/__init__.py | 0 |
| frontend/components/haptic.py | 107 |
| frontend/components/lotto_balls.py | 38 |
| frontend/lucky_engine.py | 12 |
| frontend/views/__init__.py | 0 |
| frontend/views/desktop_view.py | 8 |
| frontend/views/mobile_view.py | 96 |
| lotto_engine.py | 326 |
| lotto_stats.py | 330 |
| lucky_numbers.py | 81 |
| marketing_db.py | 265 |
| page_auto.py | 432 |
| page_birthday.py | 210 |
| page_thunder.py | 725 |
| page_thunder_GOLD_backup.py | 302 |
| page_thunder_stable_backup.py | 273 |
| premium_test.py | 77 |
| src/__init__.py | 0 |
| src/data/__init__.py | 0 |
| src/data/mock_draws.py | 15 |
| src/engine/__init__.py | 0 |
| src/engine/generator.py | 9 |
| src/engine/pipeline.py | 17 |
| src/filters/__init__.py | 0 |
| src/filters/base.py | 12 |
| src/filters/consecutive.py | 24 |
| src/filters/high_low_carry.py | 38 |
| src/filters/odd_even.py | 19 |
| src/filters/sum_range.py | 14 |
| src/models/__init__.py | 0 |
| src/models/combination.py | 41 |
| src/models/membership.py | 10 |
| src/services/__init__.py | 0 |
| src/services/combination_service.py | 55 |
| src/services/subscription.py | 30 |
| tests/test_four_filters.py | 107 |
| tests/test_marketing_db.py | 60 |
| user_page.py | 964 |
| **합계 (45개 파일)** | **6,818** |

## 통합 소스(전체 .py 연결) 통계

- 통합 파일 구분 헤더 포함 총 줄 수: **6,907**
- SOURCE_EXCERPT_FRONT.md 추출 줄 수: **1,650**
- SOURCE_EXCERPT_BACK.md 추출 줄 수: **1,650**

> 생성 기준: 프로젝트 루트 lotto-app 하위 모든 .py 파일 (알파벳 경로 순)